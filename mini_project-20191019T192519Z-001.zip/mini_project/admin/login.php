
<?php 

  require_once 'dbcon.php';

  session_start();

  if (isset($_SESSION['user_login'])) {
    header('location:index.php');
  }

  if (isset($_POST['login'])) {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    $username_check = mysqli_query($dbcon, "SELECT * FROM `users` WHERE `username` = '$username'");

    if (mysqli_num_rows($username_check) > 0) {
      $row = mysqli_fetch_assoc($username_check);

      if ($row['password'] == md5($password)) {
          if ($row['status'] == 'active') {
            $_SESSION['user_login'] = $username;
            header('location:index.php');
          } else {
            $status_inactive = "This Status is Inactive!";
          }
      } else {
         $worng_pass = "This Password is Worng!";
      }

  } else{
        
        $username_not_found = "This Username Not Found!";

  }

}

 ?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">

    <title>Student Management System</title>
  </head>
  <body>
    <div class="container animated shake">
      <br><br>
      <h1 class="text-center">Student Management System</h1>
      <br>
      <div class="row">
        <div class="col-sm-4 offset-4">
          <h2 class="text-center">Admin Login</h2>
          <br>
        <form action="" method="POST">
          <div>
            <input type="text" placeholder="Username" name="username" required="" class="form-control" value="<?php if(isset($username)){echo $username; }?>">
          </div>

          <div>
            <input type="password" placeholder="Password" name="password" required="" class="form-control" value="<?php if(isset($password)){echo $password; }?>">
          </div>
          <br>
          <div>
            <a href="../index.php" class="btn btn-secondary">Back</a>
            <input type="submit" value="Login" name="login" class="btn btn-info float-right">

          </div>
          
        </form>

        <br> <br>
        <?php if (isset($username_not_found)) {
           echo '<div class="alert alert-danger">'.$username_not_found.'</div>';}?>
        <?php if (isset($worng_pass)) {
           echo '<div class="alert alert-danger">'.$worng_pass.'</div>';}?>
        <?php if (isset($status_inactive)) {
           echo '<div class="alert alert-danger">'.$status_inactive.'</div>';}?>
           
        </div>
      </div>
    </div>

    
  </body>
</html>