
<?php
  
  require_once 'dbcon.php'; 
  
  if (isset($_POST['registration'])) {
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];
  
    $photo = $_FILES['photo']['name'];

    $photo = explode('.', $_FILES['photo']['name']);
    $photo = end($photo);

    $photo_name = $username.'.'.$photo;

    $input_error = array();

    if (empty($name)) {
      $input_error['name'] = "*The Name field is Required.";
      }
    if (empty($email)) {
      $input_error['email'] = "*The Email field is Required.";
      }
    if (empty($username)) {
      $input_error['username'] = "*The Username field is Required.";
      }
    if (empty($password)) {
      $input_error['password'] = "*The Password field is Required.";
      }
    if (empty($c_password)) {
      $input_error['c_password'] = "*The Confirm Password field is Required.";
    }

    if (empty($photo_name)) {
      $input_error['photo'] = "*The Photo is Required.";
    }

    if (count($input_error) == 0) {
        
        $email_check = mysqli_query($dbcon, "SELECT * FROM `users` WHERE `email`='$email';");

        if (mysqli_num_rows($email_check) == 0) {
          $username_check = mysqli_query($dbcon, "SELECT * FROM `users` WHERE `username`='$username';");

          if (mysqli_num_rows($username_check) == 0){
             if (strlen($username) > 7) {
               if (strlen($password) > 7) {
                 if ($password == $c_password) {
                   $password = md5($password);

                      $query = "INSERT INTO `users`(`name`, `email`, `username`, `password`, `photo`, `status`) VALUES ('$name','$email','$username','$password','$photo_name','inactive');";

                    $results = mysqli_query($dbcon, $query);

                    if ($results) {
                      $_SESSION['data_insert_success'] = "Data Insterted Successfully!";
                      move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo_name); 
                    } else{
                      $_SESSION['data_insert_error'] = "Data Insterted Error!"; 
                    }



                 } else{
                   $c_pass_match = "Confirm Password Does not Match.";
                 }
               } else{
                $password_l = "Password More Then 8 Characters.";
               }
             } else{
              $username_l = "Username More Then 8 Characters.";
             }
          } else{
            $username_error = "This Username Already Exists in Database!";
          }
        } else{
          $email_error = "This Email Already Exists!";
        }

    }

}

?>






<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="style.css">

    <title>Student Management System</title>
  </head>
  <body>
    <div class="container animated shake">
      <br><br>
      <h1 class="text-center">User Registration Form</h1>

      <?php if (isset($_SESSION['data_insert_success']))
      {echo '<div class="alert alert-success">'.$_SESSION['data_insert_success'].'</div>';}?>

      <?php if (isset($_SESSION['data_insert_error']))
      {echo '<div class="alert alert-warning">'.$_SESSION['data_insert_error'].'</div>';}?>

      <hr/>
      <div class="row">
        <div class="col-md-12">
        <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal">
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="name">Name</label>
            <div class="col-sm-6">
              <input type="text" placeholder="Enter Your Name" name="name" class="form-control" id="name">
            </div>
            <label class="error_msg"><?php if (isset($input_error['name'])) {echo $input_error['name'];} ?></label>

          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="email">Email</label>
            <div class="col-sm-6">
              <input type="email" placeholder="Enter Your Email" name="email"  class="form-control" id="email">
            </div>
            <label class="error_msg"><?php if (isset($input_error['email'])) {echo $input_error['email'];} ?></label>
            <label class="error_msg"><?php if (isset($email_error)) {echo $email_error;} ?></label>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="username">Username</label>
            <div class="col-sm-6">
              <input type="text" placeholder="Enter Your Name" name="username" class="form-control" id="username">
            </div>
            <label class="error_msg"><?php if (isset($input_error['username'])) {echo $input_error['username'];} ?></label>
            <label class="error_msg"><?php if (isset($username_error)) {echo $username_error;} ?></label>
            <label class="error_msg"><?php if (isset($username_l)) {echo $username_l;} ?></label>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="password">Password</label>
            <div class="col-sm-6">
              <input type="password" placeholder="Enter Your Password" name="password"  class="form-control" id="password">
            </div>
            <label class="error_msg"><?php if (isset($input_error['password'])) {echo $input_error['password'];} ?></label>
            <label class="error_msg"><?php if (isset($password_l)) {echo $password_l;} ?></label>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="c_password">Confirm Password</label>
            <div class="col-sm-6">
              <input type="password" placeholder="Enter Your Confirm Password" name="c_password" class="form-control" id="c_password">
            </div>
            <label class="error_msg"><?php if (isset($input_error['c_password'])) {echo $input_error['c_password'];} ?></label>
            <label class="error_msg"><?php if (isset($c_pass_match)) {echo $c_pass_match;} ?></label>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="photo">Photo</label>
            <div class="col-sm-6">
              <input type="file" name="photo"  id="photo">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-6 offset-2">
              <input type="submit" name="registration" value="Registration" class="btn btn-primary">
            </div>
          </div>
          <br>
          <p>If you have an account here? Please <a href="login.php">Login</a> </p>
          <hr>
          <footer>
            <p>Copyright &copy; 2018 - <?php echo date("Y"); ?> All right Reserved.</p>
          </footer>

         
        </form>
        </div>
      </div>
    </div>

    
  </body>
</html>