$(document).ready(function() {
    $('#data').DataTable();
} );