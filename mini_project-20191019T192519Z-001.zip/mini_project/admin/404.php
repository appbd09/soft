<div class="text-center">
	<img style="width: 100%" src="images/404.jpg" alt="">
</div>