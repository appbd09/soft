


<h1 class="text-primary"><i class="fa fa-user-plus"></i>Add Student <small>Add New Student</small></h1>
				<ol class="breadcrumb">
				  <li><i class="fa fa-dashboard"><a href="index.php?page=dashboard">Dashboard</a></i></li>
				  <li class="active"><i class="fa fa-user-plus"></i>Add Student</li>
				</ol>


<?php 
	
	if (isset($_POST['add-student'])) {
		
		$name = $_POST['name'];
		$roll = $_POST['roll'];
		$class = $_POST['class'];
		$city = $_POST['city'];
		$pcontact = $_POST['pcontact'];


		$picture = explode('.', $_FILES['photo']['name']);
		$picture_ex = end($picture);

		$picture_name = $roll.'.'.$picture_ex;

		$query = "INSERT INTO `student_info`(`name`, `roll`, `class`, `city`, `pcontact`, `photo`) VALUES ('$name','$roll','$class','$city','$pcontact','$picture_name')";

		$result = mysqli_query($dbcon, $query);

		if ($result) {
			$success = "Data Insert Successfully.";
			move_uploaded_file($_FILES['photo']['tmp_name'],'student_images/'.$picture_name);
		} else{
			$error = "Data Insert_not Successfully! This Roll Number Already in Database.";
		}
	}




 ?>


<div class="row">
	<?php if (isset($success)){echo '<div class="alert alert-success col-sm-6">'.$success.'</div>';} ?>
	<?php if (isset($error)){echo '<div class="alert alert-danger col-sm-6">'.$error.'</div>';} ?>
</div>
<div class="row">
	<div class="col-sm-6">
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label for="name">Student Name</label>
				<input type="text" name="name" placeholder="Student Name" id="name" class="form-control" required="">
			</div>
			<div class="form-group">
				<label for="roll">Roll</label>
				<input type="text" name="roll" placeholder="Roll" id="roll" class="form-control" pattern="[0-9]{6}" required="">
			</div>
			<div class="form-group">
				<label for="class">Class</label>
				<select name="class" id="class" class="form-control" required="">
					<option value="select">Select</option>
					<option value="1st">1st</option>
					<option value="2nd">2nd</option>
					<option value="3rd">3rd</option>
					<option value="4th">4th</option>
					<option value="5th">5th</option>
				</select>
			</div>
			<div class="form-group">
				<label for="city">City</label>
				<input type="text" name="city" placeholder="City" id="city" class="form-control" required="">
			</div>
			<div class="form-group">
				<label for="name">Pcontact</label>
				<input type="text" name="pcontact" placeholder="01*********" id="pcontact" class="form-control" pattern="01[1|5|6|7|8|9][0-9]{8}" required="">
			</div>
			<div class="form-group">
				<label for="photo">Photo</label>
				<input type="file" name="photo" id="photo" required="">
			</div>
			<div class="form-group">
				<input type="submit" name="add-student" value="Add Student" class="btn btn-primary pull-right">
			</div>
			
		</form>
	</div>
</div>