<?php 
	
	$dbcon = mysqli_connect("localhost","root","","mini_project");

 ?>